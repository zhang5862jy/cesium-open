# cesium-screen-callout

维护文档：[设计文档](docs/设计文档.md)、[架构文档](docs/架构文档.md)、[技术路线](docs/技术路线.md)。

可发布的 CesiumJS 屏幕空间目标标牌工具。`TargetCalloutManager` 使用一个 Worker、一个共享字形图集和少量实例化 DrawCommand 管理整批目标；单个 `WorkerCalloutHandle` 只保存状态，不创建独立 Primitive。

```ts
import { TargetCalloutManager } from "cesium-screen-callout";

const manager = new TargetCalloutManager({
  scene: viewer.scene,
  container: viewer.container,
  maxOffsetDistance: 240, // 可选；默认 Infinity，不限制
  targets: data.map((target) => ({
    position: target.position,
    lines: target.lines,
    style: target.style,
  })),
});

await manager.ready;
manager.get(0)?.setLines(["目标 001", "状态：正常"]);
manager.get(0)?.setMaxOffsetDistance(180);
manager.updateTargets({ positions, lines }, true);

// 先销毁管理器，再销毁 Viewer。
manager.destroy();
```

Cesium 是 peer dependency，不会被重复打包。包内 Worker 以内联 Blob 方式启动；严格 CSP 页面需要允许 `worker-src blob:`。发布前执行 `pnpm --filter cesium-screen-callout build`，再执行 `pnpm --filter cesium-screen-callout pack` 检查 tarball。

当前 `/examples/primitive/target-callout` 从本包导入 Worker 字形/布局计算和 WebGL2 实例化批量绘制，默认显示 1000 个目标，不创建 Entity 或立方体。原生 Cesium `TargetCallout` 小批量实现仍兼容保留。

## 数据更新和相机更新分离

- 仅位置或显隐变化、文字与样式未变化时，Worker 跳过文字布局，主线程保留现有 GPU 字符缓冲；相机投影和中心距离限制仍逐帧更新。
- 字体相同且内容未变化的行复用字形引用与测量宽度；字形纹理坐标复用，颜色解析缓存最多 256 项。逐行缓存通过 WeakMap 绑定目标，目标释放后可回收，不积累历史字符串。

- `TargetCalloutManager` 内置 Worker 计算字形和标牌布局，并合并高频目标/样式更新。目标运动或业务数据由使用方产生，通过 `updateTargets()` 批量提交；示例自己的模拟 Worker 不属于发布包。
- `GlyphBatchBuilder` 在 Worker 的 OffscreenCanvas 中维护固定 4096×4096 字形图集，可容纳多平台字体、样式和字重组合。切换样式时增量追加缺失字形，不再清空并重建全部字形；容量不足时丢弃当前未使用的缓存并重排，当前字符集合本身超限才报错。字符集合变化时才上传图集，不再把整张屏幕截图当作标牌结果。
- `ScreenBatchRenderer` 注册 Cesium primitive，在 primitive.update 中使用当前相机投影及遮挡判断，更新约 32KB 的目标参数纹理，提交两个共享实例缓冲的有序 DrawCommand：先完整绘制全部牵引线，再绘制背景、边框和文字。Cesium 可因 OIT 或多视锥派生出多次实际绘制，不再使用独立覆盖 Canvas。
- 相机平移/旋转/缩放、画布尺寸、显隐判定、命中区域和拖拽偏移按每个实际渲染帧同步，不等待 Worker 返回。即使数据间隔设为 5000ms，地图交互也不延迟 5 秒。
- 牵引线最近角在顶点着色器中按当前偏移与尺寸计算；纯拖拽不触发 Worker 文本布局重建。文字/样式变化仍按异步数据管线更新。
- 位置和实例 TypedArray 往返复用；GPU 实例缓冲按容量复用。位图上传后立即 close；卸载释放计时器、RAF、性能观察器、Worker、所属 primitive、GPU 缓冲/纹理/程序、拖拽和场景监听；共享 Cesium 上下文仅由 Viewer 管理。

## Viewer 与文字清晰度

包不擅自修改 Viewer 的相机按键映射。可选的 `applyCalloutRenderQuality(viewer)` 会避免小字号文字被低分辨率画布放大或被全屏后处理重复软化：使用设备原生像素比（超大画布受显存上限约束）、可用时启用 4× MSAA，并关闭 FXAA。返回的清理函数会恢复此前的画质设置。

模拟运动使用独立的 performance.now 计时；暂停/恢复不改 Viewer 时钟。默认高空总览和定位按钮是相机操作，不改相机控制器默认映射；仅拖动标牌期间临时锁定相机输入并在结束时恢复。

标牌直接绘入 Cesium Canvas，字体图集统一按 64px 生成，布局按用户字号缩放，同字体的不同字号共享字形。字形四边会按实际绘图缓冲区像素对齐，避免宽高端点落在半个物理像素上。画布按设备原生 DPR 输出，不做会再次缩小整张画布的额外超采样。

文字使用 Worker 生成的 SDF 距离场，而非直接缩小透明度位图。距离保存在不透明 RGB 通道，避免 ImageBitmap 预乘透明度破坏数值；每个字符保留 12 个图集像素的留白。片元着色器通过屏幕导数重建窄抗锯齿边缘，字符起点按实际绘图缓冲区像素对齐，标牌边框和牵引线仍保持原始精确偏移。文字通过普通 source-over alpha 混合叠加在背景上，实色笔画完全覆盖底色，不参与 OIT 加权混色。SDF 只在字体/字符集合变化时重建，日常数字更新继续复用图集。

## 场景深度与渲染顺序

完整保留牵引线，不裁剪标牌内部区域。先绘制整批牵引线，再按实例顺序绘制标牌背景、边框和文字；背景透明时能透出底层牵引线，半透明时按 source-over 混合，不透明时覆盖牵引线。

当前 Cesium 1.143 / engine 26.1 使用内部 `CESIUM_3D_TILE_EDGES_DIRECT` 通道作为有序直接颜色阶段。该阶段在不透明场景之后、OIT 透明场景之前执行，并保持提交顺序；两个命令均开启深度测试、关闭深度写入。不改变 Viewer 的 OIT 设置。此内部通道是版本适配点，升级 Cesium 必须验证；其他场景透明对象仍在后续透明阶段合成，标牌与它们不提供任意深度排序保证。

标牌使用绑定目标的相机空间深度，屏幕偏移只改变投影后的 XY，尺寸仍为 CSS 像素。有序绘制通道开启 depthTest、关闭 depthMask，支持 Cesium 对数深度和多视锥。更近的不透明物体可遮挡标牌，较远物体不会盖住标牌。透明物体由 Cesium OIT/透明排序合成，不提供类似 DOM z-index 的强制上下层保证。固定屏幕和拖拽时，XY 固定但深度仍取绑定目标。

构造方式：`new ScreenBatchRenderer(viewer.scene, count, () => currentFrame, () => callouts)`。Worker 返回后仍调用 `renderer.update(batch, enabled)`；渲染由 scene.primitives 自动驱动，无需 postRender 调用 draw。在 postRender 读取 `visibleCount` 并更新 Hover 按钮。计数和矩形拾取只考虑目标视口/椭球显隐，未做建筑遮挡的逐像素拾取；Hover 操作按钮仍属于 DOM UI。

DrawCommand、Buffer、Texture 等使用 Cesium 内部渲染 API，升级 Cesium 时需运行像素级回归。

## 数据接口与性能指标

文字清晰度可通过 `renderer.setTextRendering({ smoothing: 0.18, weight: 0.06, pixelSnap: true })` 实时调整，`getTextRendering()` 返回当前值。`smoothing` 范围 0–1.5，越小边缘越硬；`weight` 范围 -0.5–0.5，正值加粗、负值变细；`pixelSnap` 控制字符四边对齐实际绘图缓冲区像素。设置作用于整个批次的两个绘制通道，立即更新 uniform，不需要等待 Worker。示例在“文字清晰度”区域提供数字输入、滑块、对齐开关和恢复默认按钮，并显示可抄用的参数代码。

`WorkerCalloutHandle.setScreenFixed(true)` 将当前标牌左下角固定在画布 CSS 像素位置；`isScreenFixed()` 查询状态，`setScreenFixed(false)` 保留取消时的当前目标偏移继续跟随。固定时牵引线仍连接目标最近角，拖拽或 `setOffset()` 可重新定位固定位置，不触发 Worker 布局。未产生可见帧时开启固定返回 false。显隐沿用目标离屏/地球遮挡规则，重新可见时保留固定位置。页面固定按钮仅作用于当前目标，不受批量配置范围影响。

`WorkerCalloutHandle.setPosition()` / `setLines()` 覆盖目标模拟数据；`setStyle()`、`setOffset()`、`setDistance()`、`setShow()` 修改配置。每个实例保存独立样式；透明矩形区域可拖拽。位置/文字的覆写持续有效直到下次修改或卸载。

`setMaxOffsetDistance(px)` 限制目标点到标牌中心点的最大 CSS 像素距离，拖拽、`setOffset()` 和 `setDistance()` 都会被约束到圆形边界；传入 `Infinity` 或不配置表示不限制。管理器的 `maxOffsetDistance` 设置批次默认值，单个 target 的同名配置优先。`getMaxOffsetDistance()` 返回当前限制。标牌尺寸因文字、字号或内边距变化时会重新约束中心点。屏幕固定与距离限制同时开启时，距离限制优先，目标远离固定位置后标牌会沿限制边界跟随。

页面显示原生 Cesium FPS，以及页面 rAF FPS/P95、Worker 计算与布局时间、主线程上传时间、往返时间、JS 堆估计和长任务计数。页面 rAF、实际地图绘制、目标数据更新是不同频率，不把低频数据更新冒充高频文字变化。采样最多保存最近 120 条，每秒一条，可查看和导出。`performance.memory` 不是 GPU/Worker/进程总内存，短期 GC 波动不能证明长期零泄漏。

## 悬停与操作事件

批量绘制使用 `TargetCalloutHoverController`（`hover.ts`），通过屏幕矩形从后向前拾取最上层标牌，透明区域同样可悬停。所有标牌共享一组右上角按钮：固定/取消固定、关闭。关闭调用 `setShow(false)`，恢复调用 `setShow(true)`。在 Cesium `postRender` 中调用 `hover.update()`，目标移动时也会更新命中区域和按钮位置。卸载调用 `hover.destroy()`。

```ts
const hover = new TargetCalloutHoverController(container, viewer.canvas, () => callouts);
const unsubscribe = hover.on("mouseenter", ({ callout, properties, originalEvent }) => {
  // callout 是可调用 setStyle / setLines / setShow 等方法的原实例。
  // properties 是快照：index、position、offset、style、screenFixed、show、bounds。
  console.log(callout, properties, originalEvent);
});
hover.on("close", ({ callout, properties }) => { /* 关闭后的实例和属性 */ });
// 同样支持 mousemove、mouseleave、fixedchange；程序触发的悬停变化没有 originalEvent。
unsubscribe();
```

事件回调不参与 Worker 消息传递；属性快照中的位置、偏移和样式是副本。`close` 和 `fixedchange` 在默认动作完成后触发。

## 验证

执行 `pnpm build`，打开示例测试输入框、默认地图交互、拖拽换角、暂停、窗口缩放及退出清理。

执行 `node scripts/target-callout-efficiency-check.mjs` 验证布局缓存与未缓存输出一致、Unicode、样式/文字变更、仅位置/显隐更新及 GPU 上传跳过路径。脚本使用模拟 Canvas，耗时仅反映算法执行，不代表浏览器实际 FPS 或字体栅格化耗时。

- `/scripts/target-callout-camera-regression.html`：只发送一次 Worker 数据，测试多组相机姿态和平移；与 Cesium 当前投影对照误差，直接读取 GPU 边框/牵引线像素；四方向拖拽无需 Worker；检查只有一个 Cesium Canvas，真实不透明物体的前后遮挡，并覆盖普通/对数深度；校验 Renderer 不修改 Viewer 默认配置、图集复用和缓冲转移。
- `/scripts/target-callout-regression.html`：保留原生 Cesium 标牌回归。
- `/scripts/target-callout-worker-regression.html`：此前整屏 OffscreenCanvas 实现的算法回归，不代表当前示例的渲染管线。

## 原生 Cesium API（兼容保留）


```ts
const callout = new TargetCallout(viewer.scene, position, {
  offset: new Cartesian2(80, -80), // 创建时的 CSS 像素偏移
  style: {
    leaderColor: "#ff0000",
    borderColor: "#ff0000",
    textColor: "#ff0000",
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    fontSize: 14,
    fontFamily: "sans-serif",
    fontStyle: "normal",
    fontWeight: 400,
    lineGap: 1,
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 5,
    showBorder: true,
    showLeader: true,
  },
  maxOffsetDistance: 240, // 可选；默认 Infinity
});
callout.setPosition(nextPosition);
callout.setLines(["目标 001", "速度 140.0 m/s"]);
callout.setOffset(new Cartesian2(-180, 100));
callout.setStyle({ fontStyle: "italic", fontWeight: 700, fontSize: 20 });
callout.setShow(true);

const drag = new TargetCalloutDragController(
  viewer.scene,
  () => callouts,
  (selected) => { /* 选择当前标牌 */ },
);
// 卸载时先释放拖拽，再释放标牌，最后销毁 Viewer。
drag.destroy();
callouts.forEach((item) => item.destroy());
viewer.destroy();
```

- 上述样式均为默认值；`fontStyle` 支持 normal / bold / italic / bold italic，`fontWeight` 支持 100–900 的整百数，字号范围 8–48px。新代码建议用 `fontStyle` 表示常规/斜体、用 `fontWeight` 独立控制粗细；旧的 bold 组合值继续兼容。
- setStyle 只修改传入项，getStyle 返回副本，实例之间样式独立。
- setOffset / getOffset 是目标中心到标牌左下角的 CSS 像素偏移，x 向右、y 向下。构造 options.offset 优先于 options.distance，并复制传入坐标；原有数字 distance / 第四参 style 的调用方式仍兼容。
- 牵引线自动选择四个角中距目标中心最近的角。拖拽、字号、文本和内边距变化都会重新计算；距离相等时按左下、左上、右上、右下顺序选择。getLeaderCorner / getLeaderEndpoint 可读取当前连接角及像素坐标。
- setDistance 将方向重置为右上 45°。拖拽到其他方向后，偏移仍与缩放无关。
- 六行以内，尺寸按实际行数和文字宽度自适应，不保留原来的固定最小尺寸。lineGap 是行框之间的空隙，每行纵向步长为 fontSize + lineGap；四侧 padding 从 2px 边框内沿算起，全部支持 0–200px，行距对每一行一致。
- 背景完全透明、边框隐藏时，整个矩形区域仍能拖动。重叠时选择后创建的可见标牌。
- 拖拽使用 pointer capture，拖动期间暂停相机输入，松手、失焦、取消或销毁时恢复原状态。
- 拖动期间即使目标继续运动，抓取点也保持在指针下方；松手后保存当前偏移。
- 拖拽控制器可传第四个 onDragEnd 回调，用于松手/取消后同步偏移输入框。
- 目标在相机后、视口外或被地球椭球遮挡时隐藏。不做地形/建筑遮挡检测或标牌自动避让。

